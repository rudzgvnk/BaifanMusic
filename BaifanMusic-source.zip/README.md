# Baifan Music

Android online music player starter project with a blue liquid-glass UI.

## Features in this starter
- Search Jamendo's independent music catalog
- Play/pause and skip to next search result
- Album artwork, artist/title display
- Local favorites during the current app session
- Jetpack Compose UI with translucent glass-like cards

## Important: Jamendo API key
Register for a Jamendo API client ID from the official developer portal:
https://developer.jamendo.com/v3.0/docs

For a local build, add this line to `gradle.properties` (do not commit real secrets publicly):
`JAMENDO_CLIENT_ID=your_client_id_here`

For GitHub Actions, add a repository Actions secret named `JAMENDO_CLIENT_ID`. The workflow reads it and passes it to Gradle.

## Build APK on GitHub
1. Create a GitHub repository and upload this project.
2. Open **Settings → Secrets and variables → Actions → New repository secret**.
3. Name it `JAMENDO_CLIENT_ID` and paste your Jamendo client ID.
4. Open **Actions** and run the `Build Android APK` workflow (or push a commit).
5. Download `BaifanMusic-debug-apk` from the workflow run's Artifacts.

## Build locally
Install JDK 17 and Android SDK, then run:
`./gradlew assembleDebug`

A Gradle wrapper is not included in this starter. GitHub Actions installs Gradle 8.9.

## Notes
- Tracks and stream availability depend on Jamendo's API, territory, and each track's license/availability.
- Check each track's license and Jamendo's current API terms before distribution.
- This is a starter project; favorites are not yet persisted across app restarts.

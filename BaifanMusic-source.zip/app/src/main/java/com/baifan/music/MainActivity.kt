package com.baifan.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import java.net.URLEncoder

private val Ink = Color(0xFF071326)
private val Navy = Color(0xFF0B1F3A)
private val Blue = Color(0xFF52B8FF)
private val Ice = Color(0xFFEAF7FF)
private val Glass = Color(0x24FFFFFF)
private val Muted = Color(0xFFA9C2DA)

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val imageUrl: String,
    val audioUrl: String,
    val duration: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BaifanApp() }
    }
}

@Composable
private fun BaifanApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember {
        ExoPlayer.Builder(context).build()
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    var query by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }

    suspend fun searchTracks(term: String) {
        if (term.isBlank()) {
            error = "Ketik judul lagu atau nama artis dulu."
            return
        }
        loading = true
        error = ""
        val result = withContext(Dispatchers.IO) {
            try {
                // Add your Jamendo client_id in local.properties / GitHub Actions secret.
                val clientId = BuildConfig.JAMENDO_CLIENT_ID
                if (clientId.isBlank() || clientId == "YOUR_JAMENDO_CLIENT_ID") {
                    return@withContext SearchResult(
                        emptyList(),
                        "Tambahkan Jamendo Client ID untuk mengaktifkan pencarian musik online."
                    )
                }
                val encoded = URLEncoder.encode(term, "UTF-8")
                val url = "https://api.jamendo.com/v3.0/tracks/?client_id=$clientId&format=json&limit=25&namesearch=$encoded&audioformat=mp32"
                val request = Request.Builder().url(url).get().build()
                OkHttpClient().newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext SearchResult(emptyList(), "Server musik merespons ${response.code}.")
                    }
                    val root = JSONObject(response.body?.string().orEmpty())
                    val arr = root.optJSONArray("results")
                    val items = mutableListOf<Track>()
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            val audio = obj.optString("audio")
                            if (audio.isBlank() || audio == "null") continue
                            items.add(
                                Track(
                                    id = obj.optString("id", "$i"),
                                    title = obj.optString("name", "Unknown track"),
                                    artist = obj.optString("artist_name", "Unknown artist"),
                                    imageUrl = obj.optString("album_image", obj.optString("image", "")),
                                    audioUrl = audio,
                                    duration = obj.optInt("duration", 0)
                                )
                            )
                        }
                    }
                    SearchResult(items, if (items.isEmpty()) "Lagu tidak ditemukan. Coba kata kunci lain." else "")
                }
            } catch (e: Exception) {
                SearchResult(emptyList(), "Gagal mengambil lagu. Periksa koneksi internet.")
            }
        }
        tracks = result.tracks
        error = result.message
        loading = false
    }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF061020), Color(0xFF0B2341), Color(0xFF061020)))
        )
    ) {
        // Soft blurred glows behind translucent glass panels.
        Box(Modifier.offset(x = 235.dp, y = 70.dp).size(180.dp).blur(60.dp).background(Color(0x6651B9FF), CircleShape))
        Box(Modifier.offset(x = (-65).dp, y = 390.dp).size(190.dp).blur(70.dp).background(Color(0x443B7DFF), CircleShape))

        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF8BE0FF), Color(0xFF397BFF)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("BAIFAN", color = Ice, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("M U S I C", color = Blue, fontSize = 10.sp, letterSpacing = 4.sp)
                }
                Icon(Icons.Default.Waves, null, tint = Blue, modifier = Modifier.size(27.dp))
            }

            Column(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0x3337A9FF), Color(0x12FFFFFF), Color(0x222B6DCE))))
                    .border(1.dp, Brush.linearGradient(listOf(Color(0x88FFFFFF), Color(0x1A75BFFF))), RoundedCornerShape(28.dp))
                    .padding(20.dp)
            ) {
                Text("YOUR SOUND, YOUR SPACE", color = Blue, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(9.dp))
                Text("Find your\nnext vibe.", color = Ice, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Temukan musik baru dalam nuansa liquid glass.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Color(0x28FFFFFF))
                        .border(1.dp, Color(0x30FFFFFF), RoundedCornerShape(18.dp))
                        .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = Blue)
                    Spacer(Modifier.width(8.dp))
                    androidx.compose.foundation.text.BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Ice, fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search, capitalization = KeyboardCapitalization.None),
                        keyboardActions = KeyboardActions(onSearch = { scope.launch { searchTracks(query) } }),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text("Cari lagu atau artis...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                    IconButton(onClick = { scope.launch { searchTracks(query) } }) {
                        Icon(Icons.Default.ArrowForward, "Cari", tint = Ice)
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Explore music", color = Ice, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Musik online dari katalog independen", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Color(0x2237A9FF), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4478C8FF))) {
                    Text("ONLINE", color = Blue, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
            Spacer(Modifier.height(12.dp))

            if (loading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Blue, trackColor = Color(0x2237A9FF))
                Spacer(Modifier.height(12.dp))
            }
            if (error.isNotBlank()) {
                Text(error, color = Color(0xFFFFC6A8), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            }

            if (tracks.isEmpty() && !loading) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(Glass)
                        .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(22.dp))
                        .padding(20.dp)
                ) {
                    Icon(Icons.Default.Headphones, null, tint = Blue, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Ready when you are", color = Ice, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Cari lagu favorit untuk mulai mendengarkan.", color = Muted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = if (current != null) 120.dp else 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(tracks, key = { it.id }) { track ->
                        TrackRow(
                            track = track,
                            isCurrent = current?.id == track.id,
                            isFavorite = favorites.contains(track.id),
                            onFavorite = {
                                favorites = if (favorites.contains(track.id)) favorites - track.id else favorites + track.id
                            },
                            onPlay = {
                                current = track
                                player.setMediaItem(MediaItem.fromUri(track.audioUrl))
                                player.prepare()
                                player.play()
                                playing = true
                            }
                        )
                    }
                }
            }

            if (current != null) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xDD12385B), Color(0xCC173B66))))
                        .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(24.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AlbumThumb(current!!.imageUrl, Modifier.size(48.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(current!!.title, color = Ice, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                        Text(current!!.artist, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                    }
                    IconButton(onClick = {
                        if (player.isPlaying) {
                            player.pause()
                            playing = false
                        } else {
                            player.play()
                            playing = true
                        }
                    }) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Ice, modifier = Modifier.size(30.dp))
                    }
                    IconButton(onClick = {
                        val index = tracks.indexOfFirst { it.id == current!!.id }
                        if (index >= 0 && index + 1 < tracks.size) {
                            val next = tracks[index + 1]
                            current = next
                            player.setMediaItem(MediaItem.fromUri(next.audioUrl))
                            player.prepare()
                            player.play()
                            playing = true
                        } else {
                            Toast.makeText(context, "Cari lagu lain untuk lanjut.", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.SkipNext, "Berikutnya", tint = Blue, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}

private data class SearchResult(val tracks: List<Track>, val message: String)

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    isFavorite: Boolean,
    onFavorite: () -> Unit,
    onPlay: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(if (isCurrent) Color(0x333AAEFF) else Color(0x1CFFFFFF))
            .border(1.dp, if (isCurrent) Color(0x6684D5FF) else Color(0x1FFFFFFF), RoundedCornerShape(22.dp))
            .clickable(onClick = onPlay).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumThumb(track.imageUrl, Modifier.size(56.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Ice, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit", tint = if (isFavorite) Color(0xFFFF8BB5) else Muted, modifier = Modifier.size(20.dp))
        }
        Icon(Icons.Default.PlayCircleFilled, "Putar", tint = Blue, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun AlbumThumb(url: String, modifier: Modifier = Modifier) {
    var bitmap by remember(url) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) {
            try {
                if (url.isBlank()) null else {
                    val req = Request.Builder().url(url).build()
                    OkHttpClient().newCall(req).execute().use { response ->
                        if (response.isSuccessful) BitmapFactory.decodeStream(response.body?.byteStream()) else null
                    }
                }
            } catch (_: Exception) { null }
        }
    }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF173756)), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(bitmap!!.asImageBitmap(), contentDescription = "Album cover", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.Album, null, tint = Blue, modifier = Modifier.size(28.dp))
        }
    }
}
